train_info.csv 和 test_info.csv 中的unique_id就是對應train_data、test_data的檔名

train_data、test_data中的檔案為27次的揮拍資訊
由左至右依序為:
X軸加速度(Ax)
Y軸加速度(Ay)
Z軸加速度(Az)
X軸角速度(Gx)
Y軸角速度(Gy)
Z軸角速度(Gz)


test_answer為test_data的target

test_public_private_id為unique_id屬於public or private
